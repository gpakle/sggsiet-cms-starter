from flask_admin.contrib.sqla import ModelView
from flask import redirect, request
from ..models import User, Tenant, Page, Media, Department, Faculty
from .. import db

def init_admin(admin, app):
    # Simple admin that protects admin with login (further auth needed)
    class SecureModelView(ModelView):
        def is_accessible(self):
            # simple placeholder: allow if no auth configured
            # Replace with proper admin-only check
            return True

    admin.add_view(SecureModelView(Tenant, db.session))
    admin.add_view(SecureModelView(User, db.session))
    admin.add_view(SecureModelView(Page, db.session))
    admin.add_view(SecureModelView(Media, db.session))
    admin.add_view(SecureModelView(Department, db.session))
    admin.add_view(SecureModelView(Faculty, db.session))
