# storage abstraction available at app.media.storage
from . import storage
