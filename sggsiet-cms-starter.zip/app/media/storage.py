import os
from flask import current_app
from werkzeug.utils import secure_filename
from botocore.exceptions import BotoCoreError

ALLOWED = {'png','jpg','jpeg','gif','pdf','docx','doc'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED

def save_local(file_storage, subfolder='uploads'):
    if not allowed_file(file_storage.filename):
        raise ValueError('Invalid file type')
    filename = secure_filename(file_storage.filename)
    media_folder = current_app.config.get('MEDIA_FOLDER', os.path.join(current_app.instance_path, 'media'))
    path = os.path.join(media_folder, subfolder)
    os.makedirs(path, exist_ok=True)
    file_path = os.path.join(path, filename)
    file_storage.save(file_path)
    return file_path

def save_to_spaces(file_storage, key):
    import boto3
    session = boto3.session.Session()
    s3 = session.client('s3',
                        region_name=current_app.config.get('DO_SPACE_REGION'),
                        endpoint_url=current_app.config.get('DO_SPACE_ENDPOINT'),
                        aws_access_key_id=current_app.config.get('DO_SPACE_KEY'),
                        aws_secret_access_key=current_app.config.get('DO_SPACE_SECRET'))
    bucket = current_app.config.get('DO_SPACE_BUCKET')
    try:
        file_storage.stream.seek(0)
        s3.put_object(Bucket=bucket, Key=key, Body=file_storage.stream.read(), ACL='public-read')
    except BotoCoreError as e:
        raise
    base = current_app.config.get('DO_SPACE_BASE_URL').rstrip('/')
    return f"{base}/{key}"
