from flask import Blueprint
cms_bp = Blueprint('cms', __name__, template_folder='../templates', static_folder='../static')
from . import routes
