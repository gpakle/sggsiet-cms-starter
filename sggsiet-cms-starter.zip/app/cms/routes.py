from flask import render_template, abort
from . import cms_bp
from ..models import Page

@cms_bp.route('/')
def index():
    # simple home - show a published page with slug 'home' if exists
    page = Page.query.filter_by(slug='home', status='published').first()
    if page:
        return render_template('index.html', title=page.title, content=page.content)
    return render_template('index.html', title='Welcome to SGGSIET CMS', content='<p>Starter CMS for SGGSIET, Nanded</p>')
